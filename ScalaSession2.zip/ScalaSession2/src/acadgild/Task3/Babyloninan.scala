package acadgild.Task3

object Babyloninan extends App{
  def squareRoot(n:Double):Double = {
    var x = n
    var y = 1.000000
    
    var e = 0.000001
    while(x-y > e)
    {
      x = (x+y)/2
      y=n/x
    }
    return x
  }
  println(squareRoot(25))
}
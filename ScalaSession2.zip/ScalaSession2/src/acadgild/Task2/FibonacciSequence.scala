package acadgild.Task2

object FibonacciSequence extends App {

  def fib(n: Int) = {
    var a = 1
    var b = 1
    var i = 2
    print(a + "" + b)
    while (i < n) {
      val c = a + b
      print(c)
      a = b
      b = c
      i = i + 1
    }
  }
  print(fib(10))
}
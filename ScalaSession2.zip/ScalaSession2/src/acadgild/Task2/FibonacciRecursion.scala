package acadgild.Task2

object FibonacciRecursion extends App{
 def fib( n : Int) : Int = n match {
   case 0 | 1 => n
   case _ => fib( n-1 ) + fib( n-2 )
}
  println(fib(10))
}